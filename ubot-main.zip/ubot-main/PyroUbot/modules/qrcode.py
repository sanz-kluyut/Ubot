from PyroUbot import *

__MODULE__ = "qrcode"
__HELP__ = """
perintah : <code>{0}qrGen</code>
    merubah qrcode text menjadi gambar

perintah : <code>{0}qrRead</code>
    merubah qrcode media menjadi text
"""

