## Userbot
```
apt update && apt upgrade -y
```
```
git clone https://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@github.com/Laso-x/Ubot
```
```
cd ubot && screen -S Ubot
```
```
apt install ffmpeg -y
```
```
bash installnode.sh
```
```
apt install python3.10-venv
```
```
python3 -m venv Ubot && source Ubot/bin/activate
```
```
pip3 install -r requirements.txt
```
```
cp sample.env .env && nano .env
```
```
screen -S Ubot
```
```
python3 -m PyroUbot
```
```
---------- Menghidupan jika ubot mati -------------
```
```
cd ubotalfnew && screen -S Ubotalfnew
```
```
python3 -m venv venv && source venv/bin/activate
```
```
screen -S Ubotalfnew
```
```
python3 -m PyroUbot
```
